public class LigneEtoile
{
    public static void main(String[] args)
    {
        System.out.println("******   ******");
    }
}
